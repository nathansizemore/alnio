// Copyright 2017 Nathan Sizemore <nathanrsizemore@gmail.com>
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this file,
// you can obtain one at http://mozilla.org/MPL/2.0/.


use std::io::{self, Error, ErrorKind};
use std::mem;
use std::os::unix::io::RawFd;
use std::thread;

use epoll::{
    self,
    Events,
    EPOLL_CTL_ADD,
    EPOLL_CTL_MOD,
    EPOLL_CTL_DEL,
    EPOLLET,
    EPOLLONESHOT,
    EPOLLIN,
    EPOLLOUT,
    EPOLLERR,
    EPOLLHUP,
    EPOLLRDHUP
};
use parking_lot::Mutex;
use simple_slab::Slab;

use conn::Connection;


type ConnectionSlab = Mutex<Slab<Connection>>;


static mut EPFD: RawFd = 0;

lazy_static! {
    // static ref SLAB_MUTEX: ConnectionSlab = Mutex::new(Slab::new());
    static ref EPOLL_EVENTS_R: epoll::Events = EPOLLET | EPOLLONESHOT | EPOLLIN | EPOLLRDHUP;
    static ref EPOLL_EVENTS_RW: epoll::Events = EPOLLET | EPOLLONESHOT | EPOLLIN | EPOLLOUT | EPOLLRDHUP;
}


pub fn init() -> io::Result<()> {
    unsafe { EPFD = try!(epoll::create(true)); }
    info!("epfd: {}", epfd());
    thread::spawn(event_loop);

    return Ok(());
}

fn epfd() -> RawFd { unsafe { EPFD } }

fn epoll_rearm_r(fd: RawFd) {
    let e = epoll::Event::new(epoll_events_r(), fd as u64);
    let _ = epoll_mod(e).map_err(|err| {
        error!("During rearm_r {}", err);
    });
}

fn epoll_rearm_rw(fd: RawFd) {
    let e = epoll::Event::new(epoll_events_rw(), fd as u64);
    let _ = epoll_mod(e).map_err(|err| {
        error!("During rearm_rw {}", err);
    });
}



fn epoll_add(e: epoll::Event) -> io::Result<()> {
    epoll_ctl(EPOLL_CTL_ADD, e)
}

fn epoll_del(e: epoll::Event) -> io::Result<()> {
    epoll_ctl(EPOLL_CTL_DEL, e)
}

fn epoll_mod(e: epoll::Event) -> io::Result<()> {
    epoll_ctl(EPOLL_CTL_MOD, e)
}

fn epoll_ctl(op: epoll::ControlOptions, e: epoll::Event) -> io::Result<()> {
    epoll::ctl(epfd(), op, e.data() as RawFd, e)
}

fn close_event(e: Events) -> bool {
    (e & (EPOLLERR | EPOLLHUP | EPOLLRDHUP)).bits() > 0
}

fn read_event(e: Events) -> bool { (e & EPOLLIN).bits() > 0 }

fn write_event(e: Events) -> bool { (e & EPOLLOUT).bits() > 0 }

// pub fn add_conn(conn: Connection) -> io::Result<()> {
//     slab_add(conn);
//     let e = epoll::Event::new(epoll_events_r(), conn.socket as u64);
//     epoll_add(e)
// }

// fn slab_add_conn(c: Connection) {
//     let mut slab = (*SLAB_MUTEX).lock();
//     slab.insert(c);
// }

// fn slab_del_conn(c: &Connection) { slab_del_fd(c.as_raw_fd()); }

// fn slab_del_fd(fd: RawFd) {
//     let mut slab = (*SLAB_MUTEX).lock();

//     let mut index: isize = -1;
//     for x in 0..slab.len() {
//         if slab[x].as_raw_fd() == fd {
//             index = x as isize;
//             break;
//         }
//     }

//     if index > -1 {
//         let _ = slab.remove(index as usize);
//     } else { error!("Could not locate: {:?} in slab", fd); }
// }
