// Copyright 2017 Nathan Sizemore <nathanrsizemore@gmail.com>
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this file,
// you can obtain one at http://mozilla.org/MPL/2.0/.


use std::io::{self, Read, Write};
use std::net::TcpStream;
use std::os::unix::io::{AsRawFd, FromRawFd, RawFd};
use std::sync::Arc;

use super::super::parking_lot::Mutex;
use super::super::rlsocket;

#[derive(Clone, Debug)]
pub struct Socket {
    inner: rlsocket::Socket,
    rx_buf: Arc<Mutex<Vec<u8>>>,
    tx_buf: Arc<Mutex<Vec<u8>>>
}

impl Socket {
    /// Shutdown communication and system resources for this socket.
    pub fn close(&self) -> io::Result<()> { self.inner.close() }

    /// Creates a Socket from a TcpStream.
    pub fn from_tcpstream(s: TcpStream) -> Socket {
        Socket {
            inner: rlsocket::Socket::from_tcpstream(s),
            rx_buf: Arc::new(Mutex::new(Vec::new())),
            tx_buf: Arc::new(Mutex::new(Vec::new()))
        }
    }

    /// Copies `buf` into the rx buffer.
    pub fn rx_buf_extend(&self, buf: &[u8]) {
        lock_and_extend(&self.rx_buf, buf);
    }

    /// Returns the length of the rx buffer.
    pub fn rx_buf_len(&self) -> usize { len(&self.rx_buf) }

    /// Removes up to `buf.len()` from rx buffer and copies into `buf`.
    pub fn rx_buf_take(&self, buf: &mut [u8]) -> usize {
        lock_and_take(&self.rx_buf, buf)
    }

    /// Copies `buf` into the tx buffer.
    pub fn tx_buf_extend(&self, buf: &[u8]) {
        lock_and_extend(&self.tx_buf, buf);
    }

    /// Returns the length of the tx buffer.
    pub fn tx_buf_len(&self) -> usize { len(&self.tx_buf) }

    /// Removes up to `buf.len()` from tx buffer and copies into `buf`.
    pub fn tx_buf_take(&self, buf: &mut [u8]) -> usize {
        lock_and_take(&self.tx_buf, buf)
    }
}

impl AsRawFd for Socket {
    fn as_raw_fd(&self) -> RawFd { self.inner.as_raw_fd() }
}

impl FromRawFd for Socket {
    unsafe fn from_raw_fd(fd: RawFd) -> Socket {
        Socket {
            inner: rlsocket::Socket::from_raw_fd(fd),
            rx_buf: Arc::new(Mutex::new(Vec::new())),
            tx_buf: Arc::new(Mutex::new(Vec::new()))
        }
    }
}

impl Read for Socket {
    fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
        self.inner.read(buf)
    }
}

impl Write for Socket {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        self.inner.write(buf)
    }
    fn flush(&mut self) -> io::Result<()> { Ok(()) }
}

#[inline]
fn lock_and_extend(mutex: &Mutex<Vec<u8>>, buf: &[u8]) {
    let mut v = mutex.lock();
    (*v).extend_from_slice(buf);
}

#[inline]
fn lock_and_take(mutex: &Mutex<Vec<u8>>, buf: &mut [u8]) -> usize {
    let mut v = mutex.lock();
    let len = if (*v).len() < buf.len() { (*v).len() } else { buf.len() };
    copy(&(*v)[0..len], buf);
    (*v) = (*v).split_off(len);

    return len;
}

#[inline]
fn len(mutex: &Mutex<Vec<u8>>) -> usize {
    let v = mutex.lock();
    (*v).len()
}

#[inline]
fn copy(src: &[u8], dest: &mut [u8]) {
    for x in 0..src.len() { dest[x] = unsafe { *src.get_unchecked(x) }; }
}
