// Copyright 2016 Nathan Sizemore <nathanrsizemore@gmail.com>
//
// This Source Code Form is subject to the terms of the
// Mozilla Public License, v. 2.0. If a copy of the MPL was not distributed
// with this file, you can obtain one at http://mozilla.org/MPL/2.0/.


use std::io;
use std::net::{SocketAddr, TcpStream};
use std::os::unix::io::RawFd;

use super::socket::Socket;


pub struct Connection {
    socket: Socket,
    addr: SocketAddr
}

impl Connection {
    /// Returns the Connection's remote address
    pub fn remote_addr(&self) -> SocketAddr { self.addr }

    /// Creates a connection from a TcpStream
    pub fn from_tcpstream(s: TcpStream) -> io::Result<Connection> {
        let _ = try!(s.set_nonblocking(true));
        let addr = try!(s.peer_addr());

        Ok(Connection {
            socket: Socket::from_tcpstream(s),
            addr: addr
        })
    }

    /// Removes up to `buf.len()` bytes from this connection's receive buffer
    /// and copies them into `buf` returning the total amount copied.
    pub fn recv(&self, buf: &mut [u8]) -> usize { self.socket.rx_buf_take(buf) }

    /// Returns the total amount in the recv buffer
    pub fn recv_buf_len(&self) -> usize { self.socket.rx_buf_len() }

    /// Returns the total amount in the send buffer
    pub fn send_buf_len(&self) -> usize { self.socket.tx_buf_len() }
}
